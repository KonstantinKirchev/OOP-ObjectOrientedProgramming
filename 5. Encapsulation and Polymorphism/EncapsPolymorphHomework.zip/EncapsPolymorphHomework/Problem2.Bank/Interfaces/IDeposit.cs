﻿namespace Problem2.Bank.Interfaces
{
    public interface IDeposit
    {
        void Deposit(decimal money);
    }
}
