﻿namespace Problem2.Bank.Interfaces
{
    public interface IWithDraw
    {
        void WithDraw(decimal money);
    }
}
