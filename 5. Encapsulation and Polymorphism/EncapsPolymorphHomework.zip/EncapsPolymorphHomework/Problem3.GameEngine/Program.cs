﻿using Problem3.GameEngine.GameEngine;

namespace Problem3.GameEngine
{
    class Program
    {
        static void Main()
        {
            Engine engine = new AdvancedEngine();
            engine.Run();
        }
    }
}
