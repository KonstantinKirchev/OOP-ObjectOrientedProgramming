﻿namespace Problem3.GameEngine.Interfaces
{
    public interface IHeal
    {
        int HealingPoints { get; set; }
    }
}
