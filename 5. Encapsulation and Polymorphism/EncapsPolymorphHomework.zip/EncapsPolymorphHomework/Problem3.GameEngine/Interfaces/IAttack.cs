﻿namespace Problem3.GameEngine.Interfaces
{
    public interface IAttack
    {
        int AttackPoints { get; set; }
    }
}
