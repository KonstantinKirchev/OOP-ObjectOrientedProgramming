﻿namespace Problem3.GameEngine
{
    public enum Team
    {
        Red,
        Blue
    }
}
