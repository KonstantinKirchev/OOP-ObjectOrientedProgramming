﻿namespace Problem2.Customer
{
    public enum CustomerType
    {
        OneTime,
        Regular,
        Golden,
        Diamond
    }
}
