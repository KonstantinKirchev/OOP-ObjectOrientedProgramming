﻿namespace MassEffect.GameObjects.Ships
{
    public enum StarshipType
    {
        Frigate,
        Cruiser,
        Dreadnought
    }
}
