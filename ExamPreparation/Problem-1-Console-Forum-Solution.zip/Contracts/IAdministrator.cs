﻿namespace ConsoleForum.Contracts
{
    public interface IAdministrator : IUser
    {
    }
}
