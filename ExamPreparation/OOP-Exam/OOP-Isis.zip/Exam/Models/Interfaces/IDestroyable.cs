﻿namespace Exam.Models.Interfaces
{
    public interface IDestroyable
    {
        int Health { get; set; }
    }
}
