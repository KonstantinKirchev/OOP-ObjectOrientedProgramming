﻿namespace Exam.Models.Interfaces
{
    using Enums;

    public interface IAttackType
    {
        AttackType AttackType { get; }
    }
}
