﻿namespace Exam.Models.Interfaces
{
    using Enums;

    public interface IWarEffect
    {
        WarEffect WarEffect { get; }
    }
}
