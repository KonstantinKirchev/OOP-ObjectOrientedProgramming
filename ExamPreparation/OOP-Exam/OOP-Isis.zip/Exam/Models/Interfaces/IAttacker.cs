﻿namespace Exam.Models.Interfaces
{
    public interface IAttacker
    {
        int Damage { get; set; }
    }
}
