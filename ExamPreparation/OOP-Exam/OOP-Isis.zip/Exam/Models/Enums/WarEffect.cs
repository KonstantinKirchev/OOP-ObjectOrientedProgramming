﻿namespace Exam.Models.Enums
{
    public enum WarEffect
    {
        Jihad,
        Kamikaze
    }
}
