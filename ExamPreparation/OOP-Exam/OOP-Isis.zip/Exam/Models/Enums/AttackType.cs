﻿namespace Exam.Models.Enums
{
    public enum AttackType
    {
        Paris,
        SU24
    }
}
