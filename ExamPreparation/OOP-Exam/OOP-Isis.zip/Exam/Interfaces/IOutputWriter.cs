﻿namespace Exam.Interfaces
{
    public interface IOutputWriter
    {
        void PrintLine(string output);
    }
}
