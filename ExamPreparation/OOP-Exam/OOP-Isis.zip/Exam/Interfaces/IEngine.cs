﻿namespace Exam.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
