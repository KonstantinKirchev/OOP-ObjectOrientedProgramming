﻿namespace Exam.Interfaces
{
    public interface IInputReader
    {
        string ReadLine();
    }
}
