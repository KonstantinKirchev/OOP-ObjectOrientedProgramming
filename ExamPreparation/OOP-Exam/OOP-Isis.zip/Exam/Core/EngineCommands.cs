﻿namespace Exam.Core
{
    public static class EngineCommands
    {
        public const string CreateMilitantGroupCommand = "create";
        public const string AttackCommand = "attack";
        public const string SkipCommand = "akbar";
        public const string StatusCommand = "status";
        public const string EndCommand = "apocalypse";
    }
}
