﻿namespace Problem3.CompanyHierarchy.Enums
{
    public enum Department
    {
        Production,
        Accounting,
        Sales,
        Marketing
    }
}
