﻿namespace Problem3.CompanyHierarchy.Enums
{
    public enum State
    {
        Open,
        Closed
    }
}
