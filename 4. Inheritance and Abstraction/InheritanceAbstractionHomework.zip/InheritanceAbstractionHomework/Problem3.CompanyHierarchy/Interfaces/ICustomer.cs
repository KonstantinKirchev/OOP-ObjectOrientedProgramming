﻿namespace Problem3.CompanyHierarchy.Interfaces
{
    public interface ICustomer
    {
        decimal NetPurchaseAmount { get; set; }
    }
}
