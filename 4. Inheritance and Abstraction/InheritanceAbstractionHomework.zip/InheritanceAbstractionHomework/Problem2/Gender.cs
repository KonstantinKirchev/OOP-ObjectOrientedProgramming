﻿namespace Problem2.Animals
{
    public enum Gender
    {
        Other,
        Male,
        Female
    }
}