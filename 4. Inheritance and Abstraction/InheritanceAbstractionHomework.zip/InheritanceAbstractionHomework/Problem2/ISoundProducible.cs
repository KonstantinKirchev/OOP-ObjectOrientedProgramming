﻿namespace Problem2.Animals
{
    public interface ISoundProducible
    {
        void ProduceSound();
    }
}
