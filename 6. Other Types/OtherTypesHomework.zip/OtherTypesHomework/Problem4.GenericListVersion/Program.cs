﻿namespace Problem4.GenericListVersion
{
    class Program
    {
        static void Main()
        {
        }
    }
}
