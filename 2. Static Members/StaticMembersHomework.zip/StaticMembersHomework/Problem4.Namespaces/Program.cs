﻿namespace Problem4.Namespaces
{
    class Program
    {
        static void Main()
        {
        }
    }
}
