﻿namespace Problem4.Namespaces.Geometry.UI
{
    public class Screen2D
    {
    }
}
