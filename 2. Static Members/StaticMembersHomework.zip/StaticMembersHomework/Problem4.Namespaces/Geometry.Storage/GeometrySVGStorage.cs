﻿namespace Problem4.Namespaces.Geometry.Storage
{
    public class GeometrySVGStorage
    {
    }
}
