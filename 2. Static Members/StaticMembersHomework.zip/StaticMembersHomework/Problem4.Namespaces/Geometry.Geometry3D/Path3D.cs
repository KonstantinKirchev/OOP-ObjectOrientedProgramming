﻿namespace Problem4.Namespaces.Geometry.Geometry3D
{
    public class Path3D
    {
    }
}
