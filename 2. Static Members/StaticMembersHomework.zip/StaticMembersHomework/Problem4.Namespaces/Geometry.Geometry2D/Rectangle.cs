﻿namespace Problem4.Namespaces.Geometry.Geometry2D
{
    public class Rectangle
    {
    }
}
